int main()
{
  int b = 1, c, d = 5;
    if (d == c && b + c)
        k = j;
    else if (b <= c)
    {
      print(aux + nome);
      if (a > 4)
        x = 0;
    }
    else
    {
      int j;
      while (t > 3)
        print(1);
    }
}
