int main()
{
  int x, y, z;
  while (x < y + z * 9 - 3)
  {
    x = x - 3;
    if (x > y)
       x = 0;
    y = y + 1;
    float k;
  }
  int z;
}
