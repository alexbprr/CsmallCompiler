int main()
{
  int x, y;
  float z = x * y + x * (x + y) / (x*y) - (x + y) / x+y - y+x * x+y; 
}
