int main(){
  int a = 2, b, i;
  a = a * (a + 1);
  for (i=0; i < 4; i = i + 1)
      a = a + 1;
}
