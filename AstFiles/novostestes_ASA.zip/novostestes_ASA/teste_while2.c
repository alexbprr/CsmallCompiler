int main()
{
  int x = 1, y = 5;
  while (y > 1)
  {
    y = y - 1;
  }
  print(y);
  print(x);
}
