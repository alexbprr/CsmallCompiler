int main()
{
  int x = 0, y = 1;
  x = (3 + 2) * 23 / (9 - 2) - 12;
  y = 2 >= x > y && y <= x;
}
