int main()
{
  int x = 0, y = 1, z;
  x = 3 + 2 - x;
  if (x + y || y)
    z = 1;
  else
    z = 0;
}
