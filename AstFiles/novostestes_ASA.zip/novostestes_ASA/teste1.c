int main(){
   int a,b, c, d, e;
   float x = 2 / (3 * 5);
   a = (67 - 233) / e;
   float c = 2.456 + 343.5 * 13.15;
   if(a == c)
   {
      c = 7;
      read d;
      print(a + c);
   }
   else
      b = 1;
}
