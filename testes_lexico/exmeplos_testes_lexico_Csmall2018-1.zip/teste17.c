int main()
{
  int x = 2, y = 1, z;
  if (x + y + x)
    z = 1;
  else
    z = 0;
}
