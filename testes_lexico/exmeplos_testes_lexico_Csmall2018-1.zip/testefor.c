int main()
{
  int i = 0, j, k = 2;
  for (j = 0; j < 10; j = j + 1)
  {
      read i;
      if (i > 5)
         i = 43;
      print(i);
  }
}
