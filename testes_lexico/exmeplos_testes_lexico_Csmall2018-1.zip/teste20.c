int main(){
  int i, j;         
  for (i=0; i < 2*(4 - 3/5); i = i + 1)
      for (j=10; j > 0; j = j - 1)
}
