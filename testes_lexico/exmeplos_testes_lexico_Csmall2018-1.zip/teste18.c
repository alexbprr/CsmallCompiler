int main()
{
  int x = 2, y = 1, z;
  float j = x != y < 3 + 4 >= 2 == 1 || 4 && 5;
  if (x + y > x)
    z = 1;
  else
    z = 0;
}
