int main(){
   int b, c, d, e, t;
   float x = 2 / (3 * 5);
   a = (67 - 233) / e;
   float c = 2.456 + 343.5 * 13.15;
   if(a == c)
   {
      t = 7;
      read i;
      print(a + c);
   }
   else
      t = 1;
}
