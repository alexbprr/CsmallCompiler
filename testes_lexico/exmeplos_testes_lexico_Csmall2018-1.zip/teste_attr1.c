int main(){
   int b, d, e = 1, t;
   float x = 2 + 5 * 4;
   float a = e;
   float c = 13.15;
}
